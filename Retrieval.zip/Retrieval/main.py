"""
سیستم بازیابی متن فارسی (Persian RAG)
استخراج PDF -> چانک کردن -> امبدینگ با BGE-M3 -> ذخیره در pgvector -> جستجوی معنایی
"""

import os
import json
import fitz  # pymupdf
import psycopg2
import numpy as np
from pgvector.psycopg2 import register_vector
from langchain_text_splitters import RecursiveCharacterTextSplitter
from FlagEmbedding import BGEM3FlagModel


# ---------- تنظیمات ----------
PDF_PATH = "your_file.pdf"
CHUNK_SIZE = 200
CHUNK_OVERLAP = 40
DB_CONFIG = dict(dbname="rag_db", user="postgres", password="postgres", host="localhost")


# ---------- ۱. استخراج متن از PDF ----------
def extract_text_from_pdf(pdf_path):
    doc = fitz.open(pdf_path)
    full_text = ""
    for page in doc:
        full_text += page.get_text()
    return full_text


# ---------- ۲. چانک کردن متن ----------
def chunk_text(text, chunk_size=CHUNK_SIZE, chunk_overlap=CHUNK_OVERLAP):
    splitter = RecursiveCharacterTextSplitter(
        chunk_size=chunk_size,
        chunk_overlap=chunk_overlap,
        separators=["\n\n", "\n", ".", "؟", "!", " ", ""]
    )
    return splitter.split_text(text)


# ---------- ۳. امبد کردن چانک‌ها ----------
def embed_chunks(chunks, model):
    return model.encode(chunks, batch_size=12, max_length=8192)['dense_vecs']


# ---------- ۴. ذخیره در pgvector ----------
def store_in_pgvector(chunks, embeddings, db_config=DB_CONFIG):
    conn = psycopg2.connect(**db_config)
    register_vector(conn)
    cur = conn.cursor()

    cur.execute("""
        CREATE TABLE IF NOT EXISTS chunks (
            id SERIAL PRIMARY KEY,
            content TEXT,
            embedding VECTOR(1024)
        );
    """)
    conn.commit()

    cur.execute("TRUNCATE TABLE chunks")
    conn.commit()

    for chunk, emb in zip(chunks, embeddings):
        cur.execute(
            "INSERT INTO chunks (content, embedding) VALUES (%s, %s)",
            (chunk, emb.tolist())
        )
    conn.commit()
    return conn, cur


# ---------- ۵. جستجوی معنایی (بازیابی) ----------
def retrieve(query, conn, model, top_k=3):
    cur = conn.cursor()
    query_embedding = model.encode([query])['dense_vecs'][0]
    cur.execute(
        "SELECT content, embedding <=> %s::vector AS distance FROM chunks ORDER BY distance LIMIT %s",
        (query_embedding.tolist(), top_k)
    )
    return cur.fetchall()


# ---------- اجرای کامل پایپ‌لاین ----------
if __name__ == "__main__":
    os.makedirs("data", exist_ok=True)

    print("در حال استخراج متن از PDF ...")
    text = extract_text_from_pdf(PDF_PATH)
    with open("data/extracted_text.txt", "w", encoding="utf-8") as f:
        f.write(text)
    print(f"طول متن: {len(text)} کاراکتر")

    print("در حال چانک کردن ...")
    chunks = chunk_text(text)
    with open("data/chunks.json", "w", encoding="utf-8") as f:
        json.dump(chunks, f, ensure_ascii=False, indent=2)
    print(f"تعداد چانک‌ها: {len(chunks)}")

    print("در حال بارگذاری مدل BGE-M3 ...")
    model = BGEM3FlagModel('BAAI/bge-m3', use_fp16=True)

    print("در حال امبد کردن چانک‌ها ...")
    embeddings = embed_chunks(chunks, model)

    print("در حال ذخیره در pgvector ...")
    conn, cur = store_in_pgvector(chunks, embeddings)
    cur.execute("SELECT COUNT(*) FROM chunks")
    print("تعداد ردیف‌های ذخیره‌شده:", cur.fetchone()[0])

    print("\n--- تست جستجو ---")
    query = "معرفی به استاد"
    results = retrieve(query, conn, model, top_k=3)
    for i, (content, dist) in enumerate(results):
        print(f"\nچانک {i+1} (فاصله: {dist:.4f}):\n{content}")